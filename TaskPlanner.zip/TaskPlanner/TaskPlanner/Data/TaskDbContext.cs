﻿using System.Collections.Generic;
using TaskPlanner.Models;
using Microsoft.EntityFrameworkCore;

namespace TaskPlanner.Data
{
    public class TaskDbContext : DbContext
    {
        public TaskDbContext(DbContextOptions<TaskDbContext> options) : base(options) { }
        public DbSet<TaskItem> Tasks { get; set; }
    }
}
