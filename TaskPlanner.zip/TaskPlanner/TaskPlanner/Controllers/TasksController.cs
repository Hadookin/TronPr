using Microsoft.AspNetCore.Mvc;
using TaskPlanner.Data;
using TaskPlanner.Models;
using Microsoft.EntityFrameworkCore;


namespace TaskPlanner.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly TaskDbContext _context;
        public TasksController(TaskDbContext context) { _context = context; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<TaskItem>>> GetTasks([FromQuery] bool? completed = null)
        {
            var query = _context.Tasks.AsQueryable();
            if (completed.HasValue) query = query.Where(t => t.IsCompleted == completed.Value);
            return await query.OrderByDescending(t => t.CreatedDate).ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TaskItem>> GetTask(int id)
        {
            var task = await _context.Tasks.FindAsync(id);
            if (task == null) return NotFound();
            return task;
        }

        [HttpPost]
        public async Task<ActionResult<TaskItem>> CreateTask(TaskItem dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Title)) return BadRequest("Title is required.");
            dto.CreatedDate = DateTime.UtcNow;
            dto.IsCompleted = false;
            dto.CompletedDate = null;
            _context.Tasks.Add(dto);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetTask), new { id = dto.Id }, dto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTask(int id, TaskItem dto)
        {
            var task = await _context.Tasks.FindAsync(id);
            if (task == null) return NotFound();
            task.Title = dto.Title ?? task.Title;
            task.Description = dto.Description;
            // ��������� ������� ���������
            if (!task.IsCompleted && dto.IsCompleted)
                task.CompletedDate = DateTime.UtcNow;
            if (task.IsCompleted && !dto.IsCompleted)
                task.CompletedDate = null;
            task.IsCompleted = dto.IsCompleted;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTask(int id)
        {
            var task = await _context.Tasks.FindAsync(id);
            if (task == null) return NotFound();
            _context.Tasks.Remove(task);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

}
