﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TaskPlanner.Api
{
    public class TaskDbContext : DbContext
    {
        public TaskDbContext(DbContextOptions<TaskDbContext> options) : base(options) { }
        public DbSet<TaskItem> Tasks { get; set; }
    }
}
