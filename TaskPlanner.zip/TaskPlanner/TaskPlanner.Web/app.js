﻿const apiBase = 'https://localhost:5001/api/tasks'; // адаптировать порт

async function loadTasks() {
    const filter = document.getElementById('filter').value;
    let url = apiBase;
    if (filter === 'active') url += '?completed=false';
    if (filter === 'completed') url += '?completed=true';
    const res = await fetch(url);
    const tasks = await res.json();
    const tbody = document.querySelector('#tasksTable tbody');
    tbody.innerHTML = '';
    tasks.forEach(t => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
      <td>${escapeHtml(t.title)}</td>
      <td>${escapeHtml(t.description || '')}</td>
      <td>${new Date(t.createdDate).toLocaleString()}</td>
      <td>${t.isCompleted ? 'Выполнена' : 'Активна'}</td>
      <td>
        <button class="btn btn-sm btn-success" onclick="toggleComplete(${t.id}, ${t.isCompleted})">${t.isCompleted ? 'Снять' : 'Отметить'}</button>
        <button class="btn btn-sm btn-danger" onclick="deleteTask(${t.id})">Удалить</button>
      </td>`;
        tbody.appendChild(tr);
    });
}

async function addTask() {
    const title = document.getElementById('title').value.trim();
    const description = document.getElementById('description').value.trim();
    if (!title) { alert('Введите название'); return; }
    await fetch(apiBase, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title, description }) });
    document.getElementById('title').value = ''; document.getElementById('description').value = '';
    loadTasks();
}

async function toggleComplete(id, isCompleted) {
    await fetch(`${apiBase}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, isCompleted: !isCompleted })
    });
    loadTasks();
}

async function deleteTask(id) {
    if (!confirm('Удалить задачу?')) return;
    await fetch(`${apiBase}/${id}`, { method: 'DELETE' });
    loadTasks();
}

function escapeHtml(s) { return s ? s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;') : ''; }

document.getElementById('addBtn').addEventListener('click', addTask);
document.getElementById('filter').addEventListener('change', loadTasks);
loadTasks();
